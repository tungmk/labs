#!/usr/bin/env python3
"""
capacity_check.py

Analyze watermark capacity of a video frame using an 8x8 DCT block assumption.

Usage:
    python3 capacity_check.py frames/frame_0001.png watermark.txt output/capacity_result.txt

Capacity model:
    - The frame is divided into 8x8 blocks.
    - Each 8x8 block stores 1 bit of watermark.
    - 16 header bits are reserved to store the watermark length.
    - Total required bits = HEADER_BITS + watermark_bytes * 8.
"""

import argparse
from pathlib import Path

try:
    import cv2
except ImportError:
    cv2 = None


DEFAULT_BLOCK_SIZE = 8
DEFAULT_HEADER_BITS = 16
DEFAULT_BITS_PER_BLOCK = 1


def read_image_size(image_path):
    """
    Return width, height, and number of channels of the input image.
    """
    if cv2 is None:
        raise RuntimeError(
            "OpenCV is not installed. Please install python3-opencv or opencv-python."
        )

    image = cv2.imread(str(image_path), cv2.IMREAD_UNCHANGED)

    if image is None:
        raise ValueError("Cannot read image: {}".format(image_path))

    height, width = image.shape[:2]

    if len(image.shape) == 2:
        channels = 1
    else:
        channels = image.shape[2]

    return width, height, channels


def analyze_capacity(frame_path, watermark_path, block_size, header_bits, bits_per_block):
    """
    Analyze the watermark capacity of one frame.
    """
    if not frame_path.is_file():
        raise FileNotFoundError("Frame image not found: {}".format(frame_path))

    if not watermark_path.is_file():
        raise FileNotFoundError("Watermark file not found: {}".format(watermark_path))

    if block_size <= 0:
        raise ValueError("block_size must be greater than 0")

    if header_bits < 0:
        raise ValueError("header_bits must be greater than or equal to 0")

    if bits_per_block <= 0:
        raise ValueError("bits_per_block must be greater than 0")

    width, height, channels = read_image_size(frame_path)

    blocks_horizontal = width // block_size
    blocks_vertical = height // block_size
    total_blocks = blocks_horizontal * blocks_vertical

    usable_width = blocks_horizontal * block_size
    usable_height = blocks_vertical * block_size

    capacity_bits = total_blocks * bits_per_block
    capacity_bytes = capacity_bits // 8

    watermark_text = watermark_path.read_text(encoding="utf-8").strip()
    watermark_bytes = watermark_text.encode("utf-8")

    watermark_byte_length = len(watermark_bytes)
    watermark_bits = watermark_byte_length * 8

    total_required_bits = header_bits + watermark_bits

    if total_required_bits <= capacity_bits:
        status = "ENOUGH_CAPACITY"
    else:
        status = "NOT_ENOUGH_CAPACITY"

    unused_bits = capacity_bits - total_required_bits

    if unused_bits >= 0:
        unused_bytes = unused_bits // 8
    else:
        unused_bytes = 0

    lines = [
        "CAPACITY_ANALYSIS_RESULT",
        "FRAME={}".format(frame_path),
        "WIDTH={}".format(width),
        "HEIGHT={}".format(height),
        "CHANNELS={}".format(channels),
        "BLOCK_SIZE={}x{}".format(block_size, block_size),
        "USABLE_WIDTH={}".format(usable_width),
        "USABLE_HEIGHT={}".format(usable_height),
        "BLOCKS_HORIZONTAL={}".format(blocks_horizontal),
        "BLOCKS_VERTICAL={}".format(blocks_vertical),
        "TOTAL_BLOCKS={}".format(total_blocks),
        "BITS_PER_BLOCK={}".format(bits_per_block),
        "CAPACITY_BITS={}".format(capacity_bits),
        "CAPACITY_BYTES={}".format(capacity_bytes),
        "WATERMARK_FILE={}".format(watermark_path),
        "WATERMARK_TEXT={}".format(watermark_text),
        "WATERMARK_BYTES={}".format(watermark_byte_length),
        "WATERMARK_BITS={}".format(watermark_bits),
        "HEADER_BITS={}".format(header_bits),
        "TOTAL_REQUIRED_BITS={}".format(total_required_bits),
        "UNUSED_BITS={}".format(unused_bits),
        "UNUSED_BYTES={}".format(unused_bytes),
        "STATUS={}".format(status),
    ]

    if blocks_horizontal == 0 or blocks_vertical == 0:
        lines.append("WARNING=Frame is smaller than one complete block.")

    if width % block_size != 0 or height % block_size != 0:
        lines.append(
            "NOTE=Frame dimensions are not fully divisible by block size; "
            "edge pixels outside complete blocks are not counted."
        )

    if status == "ENOUGH_CAPACITY":
        lines.append(
            "CONCLUSION=This frame can store the watermark using the selected capacity model."
        )
    else:
        lines.append(
            "CONCLUSION=This frame cannot store the watermark because required bits exceed capacity."
        )

    return lines


def main():
    parser = argparse.ArgumentParser(
        description="Analyze watermark capacity of a frame using an 8x8 block-based DCT capacity model."
    )

    parser.add_argument(
        "frame",
        help="Input frame image, for example: frames/frame_0001.png"
    )

    parser.add_argument(
        "watermark",
        help="Watermark text file, for example: watermark.txt"
    )

    parser.add_argument(
        "output",
        help="Output result file, for example: output/capacity_result.txt"
    )

    parser.add_argument(
        "--block-size",
        type=int,
        default=DEFAULT_BLOCK_SIZE,
        help="Block size used for capacity calculation. Default: 8"
    )

    parser.add_argument(
        "--header-bits",
        type=int,
        default=DEFAULT_HEADER_BITS,
        help="Number of header bits reserved for watermark length. Default: 16"
    )

    parser.add_argument(
        "--bits-per-block",
        type=int,
        default=DEFAULT_BITS_PER_BLOCK,
        help="Number of watermark bits stored per block. Default: 1"
    )

    args = parser.parse_args()

    frame_path = Path(args.frame)
    watermark_path = Path(args.watermark)
    output_path = Path(args.output)

    try:
        lines = analyze_capacity(
            frame_path=frame_path,
            watermark_path=watermark_path,
            block_size=args.block_size,
            header_bits=args.header_bits,
            bits_per_block=args.bits_per_block,
        )
    except Exception as exc:
        error_lines = [
            "CAPACITY_ANALYSIS_RESULT",
            "STATUS=ERROR",
            "ERROR={}".format(exc),
        ]

        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text("\n".join(error_lines) + "\n", encoding="utf-8")

        print("\n".join(error_lines))
        return 1

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    print("\n".join(lines))
    print("\nResult saved to: {}".format(output_path))

    return 0


if __name__ == "__main__":
    raise SystemExit(main())

