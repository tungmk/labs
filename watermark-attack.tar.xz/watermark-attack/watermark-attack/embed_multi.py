#!/usr/bin/env python3
import argparse
from pathlib import Path

import cv2
import numpy as np

BLOCK_SIZE = 8
HEADER_BITS = 16  # store watermark byte length in first 16 bits


def read_targets(targets_file: Path):
    targets = []
    for raw_line in targets_file.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip().replace("\r", "")
        if not line or line.startswith("#"):
            continue
        targets.append(line)
    return targets


def text_to_bits(text: str):
    data = text.encode("utf-8")
    if len(data) > 65535:
        raise ValueError("Watermark is too long. Maximum length is 65535 bytes.")

    bits = []
    length_bits = f"{len(data):016b}"
    bits.extend(int(b) for b in length_bits)

    for byte in data:
        bits.extend(int(b) for b in f"{byte:08b}")

    return bits


def force_dc_bit(dc_value: float, bit: int, delta: float):
    sign = 1.0 if dc_value >= 0 else -1.0
    abs_dc = abs(float(dc_value))

    q = int(abs_dc // delta)
    if q % 2 != bit:
        q += 1

    new_dc = sign * (q * delta + delta / 2.0)
    return new_dc


def embed_message_in_image(input_image: Path, output_image: Path, message: str, delta: float):
    img = cv2.imread(str(input_image), cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError(f"Cannot read image: {input_image}")

    ycrcb = cv2.cvtColor(img, cv2.COLOR_BGR2YCrCb).astype(np.float32)
    y = ycrcb[:, :, 0]

    h, w = y.shape
    h8 = (h // BLOCK_SIZE) * BLOCK_SIZE
    w8 = (w // BLOCK_SIZE) * BLOCK_SIZE

    if h8 == 0 or w8 == 0:
        raise ValueError(f"Image too small for DCT embedding: {input_image}")

    y_crop = y[:h8, :w8].copy()

    blocks_h = h8 // BLOCK_SIZE
    blocks_w = w8 // BLOCK_SIZE
    capacity_bits = blocks_h * blocks_w

    bits = text_to_bits(message)

    if len(bits) > capacity_bits:
        raise ValueError(
            f"Not enough capacity in image {input_image}. "
            f"Need {len(bits)} bits, but only {capacity_bits} bits available."
        )

    bit_index = 0

    for br in range(blocks_h):
        for bc in range(blocks_w):
            r = br * BLOCK_SIZE
            c = bc * BLOCK_SIZE

            block = y_crop[r:r + BLOCK_SIZE, c:c + BLOCK_SIZE].astype(np.float32)
            dct_block = cv2.dct(block)

            if bit_index < len(bits):
                dct_block[0, 0] = force_dc_bit(dct_block[0, 0], bits[bit_index], delta)
                bit_index += 1

            idct_block = cv2.idct(dct_block)
            y_crop[r:r + BLOCK_SIZE, c:c + BLOCK_SIZE] = np.clip(idct_block, 0, 255)

    ycrcb[:h8, :w8, 0] = y_crop
    out_img = cv2.cvtColor(np.clip(ycrcb, 0, 255).astype(np.uint8), cv2.COLOR_YCrCb2BGR)

    output_image.parent.mkdir(parents=True, exist_ok=True)
    ok = cv2.imwrite(str(output_image), out_img)
    if not ok:
        raise ValueError(f"Cannot write output image: {output_image}")


def main():
    parser = argparse.ArgumentParser(
        description="Embed one watermark into multiple target frames using DC-DCT parity embedding."
    )
    parser.add_argument("frames_dir", help="Directory containing extracted frames")
    parser.add_argument("targets_file", help="Text file listing target frame names")
    parser.add_argument("watermark_file", help="Text file containing the watermark")
    parser.add_argument("output_dir", help="Directory to save watermarked frames")
    parser.add_argument("-d", "--delta", type=float, default=20.0,
                        help="Quantization step for DC embedding (default: 20.0)")

    args = parser.parse_args()

    frames_dir = Path(args.frames_dir)
    targets_file = Path(args.targets_file)
    watermark_file = Path(args.watermark_file)
    output_dir = Path(args.output_dir)

    if not frames_dir.is_dir():
        raise SystemExit(f"ERROR: frames directory not found: {frames_dir}")

    if not targets_file.is_file():
        raise SystemExit(f"ERROR: targets file not found: {targets_file}")

    if not watermark_file.is_file():
        raise SystemExit(f"ERROR: watermark file not found: {watermark_file}")

    watermark = watermark_file.read_text(encoding="utf-8").strip()
    if not watermark:
        raise SystemExit("ERROR: watermark.txt is empty")

    targets = read_targets(targets_file)
    if not targets:
        raise SystemExit("ERROR: frame_targets.txt does not contain any frame name")

    output_dir.mkdir(parents=True, exist_ok=True)

    success_count = 0
    failed = []

    print(f"Watermark: {watermark}")
    print(f"Target frames: {len(targets)}")
    print("-" * 60)

    for frame_name in targets:
        input_frame = frames_dir / frame_name
        output_frame = output_dir / frame_name

        if not input_frame.is_file():
            print(f"FAIL: missing input frame: {input_frame}")
            failed.append(frame_name)
            continue

        try:
            embed_message_in_image(input_frame, output_frame, watermark, args.delta)
            print(f"OK: {input_frame} -> {output_frame}")
            success_count += 1
        except Exception as exc:
            print(f"FAIL: {frame_name} -> {exc}")
            failed.append(frame_name)

    print("-" * 60)
    print(f"MULTI_EMBED_DONE: {success_count}/{len(targets)}")

    if failed:
        print("FAILED_FRAMES=" + ",".join(failed))

    raise SystemExit(0 if success_count == len(targets) else 1)


if __name__ == "__main__":
    main()

