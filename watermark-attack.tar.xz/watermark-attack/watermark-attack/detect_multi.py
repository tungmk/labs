#!/usr/bin/env python3
import argparse
from pathlib import Path

import cv2
import numpy as np

BLOCK_SIZE = 8
HEADER_BITS = 16


def read_targets(targets_file: Path):
    targets = []
    for raw_line in targets_file.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip().replace("\r", "")
        if not line or line.startswith("#"):
            continue
        targets.append(line)
    return targets


def bits_to_int(bits):
    return int("".join(str(b) for b in bits), 2)


def extract_dc_bit(dc_value: float, delta: float):
    q = int(abs(float(dc_value)) // delta)
    return q % 2


def extract_message_from_image(input_image: Path, delta: float, max_bytes: int):
    img = cv2.imread(str(input_image), cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError(f"Cannot read image: {input_image}")

    ycrcb = cv2.cvtColor(img, cv2.COLOR_BGR2YCrCb).astype(np.float32)
    y = ycrcb[:, :, 0]

    h, w = y.shape
    h8 = (h // BLOCK_SIZE) * BLOCK_SIZE
    w8 = (w // BLOCK_SIZE) * BLOCK_SIZE

    if h8 == 0 or w8 == 0:
        raise ValueError(f"Image too small for DCT detection: {input_image}")

    blocks_h = h8 // BLOCK_SIZE
    blocks_w = w8 // BLOCK_SIZE
    capacity_bits = blocks_h * blocks_w

    if capacity_bits < HEADER_BITS:
        raise ValueError("Image does not contain enough blocks to store header")

    extracted_bits = []

    for br in range(blocks_h):
        for bc in range(blocks_w):
            r = br * BLOCK_SIZE
            c = bc * BLOCK_SIZE

            block = y[r:r + BLOCK_SIZE, c:c + BLOCK_SIZE].astype(np.float32)
            dct_block = cv2.dct(block)
            bit = extract_dc_bit(dct_block[0, 0], delta)
            extracted_bits.append(bit)

    header = extracted_bits[:HEADER_BITS]
    payload_len = bits_to_int(header)

    if payload_len <= 0:
        raise ValueError("Decoded watermark length is invalid (<= 0)")

    if payload_len > max_bytes:
        raise ValueError(f"Decoded watermark length {payload_len} exceeds max_bytes={max_bytes}")

    total_bits_needed = HEADER_BITS + payload_len * 8

    if total_bits_needed > capacity_bits:
        raise ValueError(
            f"Decoded payload length requires {total_bits_needed} bits, "
            f"but only {capacity_bits} bits are available"
        )

    payload_bits = extracted_bits[HEADER_BITS:total_bits_needed]

    data = bytearray()
    for i in range(0, len(payload_bits), 8):
        byte_bits = payload_bits[i:i + 8]
        value = bits_to_int(byte_bits)
        data.append(value)

    try:
        message = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise ValueError(f"Cannot decode extracted watermark as UTF-8: {exc}")

    return message


def main():
    parser = argparse.ArgumentParser(
        description="Detect watermark from multiple target frames using DC-DCT parity decoding."
    )
    parser.add_argument("frames_dir", help="Directory containing frames to detect")
    parser.add_argument("targets_file", help="Text file listing target frame names")
    parser.add_argument("result_file", help="Text file to save detection result")
    parser.add_argument("--expected", default=None,
                        help="Optional watermark.txt used to check MATCH/MISMATCH")
    parser.add_argument("-d", "--delta", type=float, default=20.0,
                        help="Quantization step used during embedding (default: 20.0)")
    parser.add_argument("--max-bytes", type=int, default=256,
                        help="Maximum allowed extracted watermark size in bytes (default: 256)")

    args = parser.parse_args()

    frames_dir = Path(args.frames_dir)
    targets_file = Path(args.targets_file)
    result_file = Path(args.result_file)

    if not frames_dir.is_dir():
        raise SystemExit(f"ERROR: frames directory not found: {frames_dir}")

    if not targets_file.is_file():
        raise SystemExit(f"ERROR: targets file not found: {targets_file}")

    expected_value = None
    if args.expected is not None:
        expected_file = Path(args.expected)
        if not expected_file.is_file():
            raise SystemExit(f"ERROR: expected watermark file not found: {expected_file}")
        expected_value = expected_file.read_text(encoding="utf-8").strip()
        if not expected_value:
            raise SystemExit("ERROR: expected watermark file is empty")

    targets = read_targets(targets_file)
    if not targets:
        raise SystemExit("ERROR: frame_targets.txt does not contain any frame name")

    result_file.parent.mkdir(parents=True, exist_ok=True)

    detected_count = 0
    matched_count = 0
    result_lines = []

    print(f"Target frames: {len(targets)}")
    if expected_value is not None:
        print(f"Expected watermark: {expected_value}")
    print("-" * 60)

    for frame_name in targets:
        input_frame = frames_dir / frame_name

        if not input_frame.is_file():
            line = f"{frame_name}: NOT_FOUND"
            print(line)
            result_lines.append(line)
            continue

        try:
            detected_value = extract_message_from_image(input_frame, args.delta, args.max_bytes)
        except Exception:
            detected_value = "NOT_FOUND"

        if detected_value != "NOT_FOUND":
            detected_count += 1

        if expected_value is not None:
            status = "MATCH" if detected_value == expected_value else "MISMATCH"
            if status == "MATCH":
                matched_count += 1
            line = f"{frame_name}: {detected_value} [{status}]"
        else:
            line = f"{frame_name}: {detected_value}"

        print(line)
        result_lines.append(line)

    result_lines.append("")
    result_lines.append(f"DETECTED_COUNT={detected_count}")
    result_lines.append(f"TOTAL_TARGETS={len(targets)}")

    if expected_value is not None:
        result_lines.append(f"MATCHED_COUNT={matched_count}")
        result_lines.append(f"EXPECTED_WATERMARK={expected_value}")

    result_file.write_text("\n".join(result_lines) + "\n", encoding="utf-8")

    print("-" * 60)
    print(f"MULTI_DETECT_DONE: {detected_count}/{len(targets)}")

    if expected_value is not None:
        print(f"MULTI_MATCH_DONE: {matched_count}/{len(targets)}")

    print(f"Result saved to: {result_file}")

    raise SystemExit(0 if detected_count > 0 else 1)


if __name__ == "__main__":
    main()

